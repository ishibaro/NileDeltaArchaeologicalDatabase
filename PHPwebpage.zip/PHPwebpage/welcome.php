<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
// Check user role,and redirects if necessary
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
}
elseif(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true && $_SESSION['role']=="2"){
	header("location: welcome2.php");
}
elseif(!isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] !== true && $_SESSION['role']!="1"){
	header("location: login.php");
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome</title>
    <style type="text/css">
        body{ font: 14px sans-serif; text-align: center; }
    </style>
</head>
<body>
    <div class="jumbotron">
		<h1 class="display-4">Hi, <b><?php echo htmlspecialchars($_SESSION["username"]); ?></b></h1>
        <p class="lead">Welcome to Temporalities Database website.</p>
		<hr class="my-4">
		<p>Select the option of your choice.</p>
    
	
	<p>
        <a href="temporalDBpg/index.php" class="btn btn-primary" data-toggle="tooltip" data-placement="top" title="Site form to input data to the temporality database">Add temporality for site</a>
        <a href="temporalDBpg/query/index.php" class="btn btn-info" data-toggle="tooltip" data-placement="top" title="Look up site information available">Query site only</a>
    </p>
    <p>
        <a href="reset-password.php" class="btn btn-warning">Reset Your Password</a>
        <a href="logout.php" class="btn btn-danger">Sign Out of Your Account</a>
    </p>
	</div>
	
	<!--Bootstrap files-->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>