<?php
require_once ("dbcontroller.php");
$db_handle = new DbConnect();
if (! empty($_POST["id_lon"])) {
	$query = "SELECT * FROM medper WHERE 
		idkey = '" . $_POST["id_lon"] . "' order by medper asc";
	$results = $db_handle->runQuery($query);
	?>
<option value disabled selected>Select Cycle</option>
<?php
	foreach ($results as $medper) {
		?>
<option value="<?php echo $medper["id"]; ?>"><?php echo $medper["medperiod"]; ?></option>
<?php
	}
}
?>