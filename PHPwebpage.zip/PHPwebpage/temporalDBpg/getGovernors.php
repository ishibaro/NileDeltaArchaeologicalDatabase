<?php
require_once ("dbcontroller.php");
$db_handle = new DbConnect();
if (! empty($_POST["id_sho"])) {
	$query = "SELECT * FROM governors WHERE 
		shortper_id = '" . $_POST["id_sho"] . "' order by year01 asc";
	$results = $db_handle->runQuery($query);
	?>
<option value disabled selected>Select centre</option>
<?php
	foreach ($results as $governors) {
		?>
<option value="<?php echo $governors["id"]; ?>"><?php echo $governors["rulers"]; ?></option>
<?php
	}
}
?>