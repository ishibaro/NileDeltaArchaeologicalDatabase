﻿<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
// Check user role,and redirects if necessary
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
}
elseif(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true && $_SESSION['role']=="2"){
	header("location: query/index.php");
}
elseif(!isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] !== true && $_SESSION['role']!="1"){
	header("location: ../welcome2.php");
}
?>

<?php
require_once("dbcontroller.php");
$db_handle = new DbConnect();
$query ="SELECT * FROM lonper";
$results = $db_handle->runQuery($query);
?>

<?php
require_once("dbcontroller.php");
$db_handle = new DbConnect();
$queryES ="SELECT * FROM eessite";
$resultsSet = $db_handle->runQuery($queryES);
?>


<!DOCTYPE html>
<html>
<head>
	<title> Temporalities input </title>
</head>
	
	<!--jquery for Ajax see dbcontroller.php-->
	<script src="scripts/jquery-3.5.1.min.js" type="text/javascript"></script>
	<!--As used in https://www.youtube.com/watch?v=olTcgHliIhM 
	Chosen version https://github.com/harvesthq/chosen/releases/-->
	<script src="scripts/chosen/chosen.jquery.min.js" type="text/javascript"></script>
	<link href="scripts/chosen/chosen.min.css" rel="stylesheet"/>
	<link href="scripts/styletemp.css" rel="stylesheet"/>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	
	<script type="text/javascript">
		
		function getMedper(val){
			$.ajax({
				type: "POST",
				url:  "getMedper.php",
				data: 'id_lon='+val,
				success:function(data){
					$("#medperlist").html(data);
					getShortper();
				}
			});
		}
		function getShortper(val){
			$.ajax({
				type: "POST",
				url:  "getShortper.php",
				data: 'id_med='+val,
				success:function(data){
					$("#shortperlist").html(data);
				}
			});
		}
		
		function getGovernors(val){
			$.ajax({
				type: "POST",
				url:  "getGovernors.php",
				data: 'id_sho='+val,
				success:function(data){
					$("#govslist").html(data);
				}
			});
		}
		
		function getSite(val){
			$.ajax({
				type: "POST",
				url:  "getCoords.php",
				data: 'id_site='+val,
				success:function(data){
					$("#polka").html(data);
				}
			});
		}
	</script>
	<body>
	<h3> Temporalities </h3>
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <!-- Navbar content -->
    <a href="../welcome.php" class="btn btn-danger">Menu</a>-->
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarColor01">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item active">
          <a class="nav-link" href="#">Add temporality<span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="query/index.php">Site query</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="../logout.php">Logout</a>
        </li>
      </ul>
    </div>
  </nav>
	<div class="divTable">
	<form action="action.php" method="POST">
			<div class="divTableBody">
				<div class="divTableRow">
					<div class="divTableCell">
						<label> Site: </label><br>
						<select name="name" id="searchddl" onchange="getSite(this.value);">
							<option> Select site</option>
							<?php
							foreach($resultsSet as $site) {
							?>
							<option value="<?php echo $site["id"]; ?>">
							<?php echo $site["no_"]; ?>, <?php echo $site["name"]; ?>
							</option>
							<?php
							}
							?>
						</select>
					</div>
						<div class="divTableCell">
						<label> Long period: </label><br>
							<select name="lonper" id="lonperlist" class="InputBox" onChange="getMedper(this.value);">
								<option value disabled selected> Select period</option>
								<?php
								foreach($results as $lonper) {
								?>
								<option value="<?php echo $lonper["id"]; ?>">
								<?php echo $lonper["lonperiod"]; ?>
								</option>
								<?php
								}
								?>
							</select>
						</div>
						<div class="divTableCell">
						<input type="submit" class="btn btn-primary" name="insert" value="INSERT DATA"/>
						</div>
						</div>
				<div class="divTableRow">
					<div class="divTableCell">
						<label> Cycle: </label><br>
							<select name="medper" id="medperlist" class="InputBox" onChange="getShortper(this.value);">
								<option value=""> Select cycle</option>
							</select>
						</div>
						<div class="divTableCell">
						<label> Centre of power: </label><br>
							<select name="shortper" id="shortperlist" class="InputBox" onChange="getGovernors(this.value);">>
								<option value=""> Select centre</option>
							</select>
						</div>
						<div class="divTableCell">
						<label> Ruler: </label><br>
							<select name="governors" id="govslist" class="InputBox" > 
								<option value=""> Select ruler</option>
							</select>
						</div>
							
						</form>
						</div>
						</div>
						</div>
			
			<div id="polka"></div>


		<script>
			$("#searchddl").chosen();
		</script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
	</body>
</html>