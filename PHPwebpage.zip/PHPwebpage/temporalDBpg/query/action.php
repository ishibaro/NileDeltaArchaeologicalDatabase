<?php
	header("Location:index.php");
	
		//---este forma usa procedimientos, pero el controlador de la base de datos es OO
		//entonces llamamos al controlaor con require_once
		//$dbconn = pg_connect("host=postgresql-ishiba.alwaysdata.net port=5432 dbname=ishiba_polka user=ishiba password=MNBV5q6a")
		//conectarse a una base de datos llamada "temporalitytest" en el host "alwaysdata" con el nombre de usuario y password
		//or die('No se ha podido conectar: ' . pg_last_error());
		//esto pasa si no se conecta
		//https://www.php.net/manual/es/pgsql.examples-basic.php
		
		require_once ("dbcontroller.php");
		$db_handle = new DbConnect();
		
				$name = $_POST['name'];				
				$lonper = $_POST['lonper'];
				$medper = $_POST['medper'];
								
				if(empty($_POST['governors'])){
				$governors = '0';
				}else{
				$governors = $_POST['governors'];
				}
				
				if(empty($_POST['shortper'])){
				$shortper = '0';
				}else{
				$shortper = $_POST['shortper'];
				}
				
				$query ="
					INSERT INTO temporalitytest(
						idsite,
						idlon,
						idmed,
						idshort,
						idgov
					)
					VALUES (
					'$name',
					'$lonper',
					'$medper',
					'$shortper',
					'$governors'
					)";
				
				//Y en lugar de usar este comando por procedimientos
				//$query_run = pg_query($dbconn,$query);
				//usamos el comando OO
				$query_run = $db_handle->runQuery($query);
				
?>