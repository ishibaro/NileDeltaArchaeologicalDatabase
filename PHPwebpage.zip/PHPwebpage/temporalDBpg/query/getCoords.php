<?php
require_once ("dbcontroller.php");
$db_handle = new DbConnect();
if (! empty($_POST["id_site"])) {
	$query = "SELECT * FROM eessite WHERE 
		id = '" . $_POST["id_site"] . "'";
	$results = $db_handle->runQuery($query);
	
	?>
	
				
					<table>
						<?php				
							foreach ($results as $infosite) {
								?>
								<tr>
									<th style="width:10%"> ID</th>
									<th style="width:20%"> NAME</th>
									<th style="width:70%"> NOTES</th>
								
								</tr>
								<tr>
									<td> <?php echo $infosite["no_"]; ?> </td>
									<td> <?php echo $infosite["name"]; ?> </td>
									<td> <?php echo $infosite['notes']; ?> </td>
								</tr>
								<tr>
									<td colspan="2" style="font-weight:bold;"> Northing </td>
									<td colspan="1" style="font-weight:bold;"> Easting </td>
								</tr>
								<tr>
									<td colspan="2"> <?php echo $infosite['easting']; ?> </td>
									<td colspan="1"> <?php echo $infosite['northing']; ?> </td>
								</tr>
								<tr>
									<td colspan="3"><div id="googleMap" style="width:100%;height:250px;"></div>
								<?php
								// https://www.w3schools.com/graphics/google_maps_basic.asp
								?>
								<script>
									function myMap() {
										var mapProp= {
										  center:new google.maps.LatLng
										  (
										  <?php echo $infosite['latitude']; ?>,
										  <?php echo $infosite['longitude']; ?>),
										  zoom:16,
										  mapTypeId: google.maps.MapTypeId.HYBRID,
										};
										var map = new google.maps.Map(document.getElementById("googleMap"),mapProp);
									}
								</script>

								<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBRSe24NQ_NjvnasgDiEBa4Fm88qMNEONk&callback=myMap"></script>
									</td>
								
								
								
								<?php
								}
						?>
					</table>
					
						<?php
					}
?>

<?php
	echo "The following cycles have been associated";
	
	$dbconn = pg_connect("host=postgresql-ishiba.alwaysdata.net port=5432 dbname=ishiba_tg user=ishiba password=MNBV5q6a")
	//conectarse a una base de datos llamada "mary" en el host "sheep" con el nombre de usuario y password
	or die('No se ha podido conectar: ' . pg_last_error());
	//esto pasa si no se conecta

	//https://www.php.net/manual/es/pgsql.examples-basic.php
	// Realizando una consulta SQL
    $query = "SELECT
					ideesof,
					name,
					lonperiod,
					medperiod,
					starcheo,
					enarcheo 
				FROM medarcheomodid
				WHERE 
			idint = '" . $_POST["id_site"] . "' order by starcheo asc";
    $result = pg_query($query) or die('La consulta fallo: ' . pg_last_error());

    // Imprimiendo los resultados en HTML
	echo "<table>\n";
	while ($line = pg_fetch_array($result, null, PGSQL_ASSOC)) {
		echo "\t<tr>\n";
		foreach ($line as $col_value) {
			echo "\t\t<td>$col_value</td>\n";
		}
		echo "\t</tr>\n";
	}
	echo "</table>\n";

	// Liberando el conjunto de resultados
	pg_free_result($result);

	// Cerrando la conexión
	pg_close($dbconn);
?>