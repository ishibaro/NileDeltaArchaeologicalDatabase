<?php
require_once ("dbcontroller.php");
$db_handle = new DbConnect();
if (! empty($_POST["id_med"])) {
	$query = "SELECT * FROM shortper WHERE 
		idmedn = '" . $_POST["id_med"] . "' order by shoperiod asc";
	$results = $db_handle->runQuery($query);
	?>
<option value disabled selected>Select centre</option>
<?php
	foreach ($results as $shortper) {
		?>
<option value="<?php echo $shortper["id"]; ?>"><?php echo $shortper["shoperiod"]; ?></option>
<?php
	}
}
?>