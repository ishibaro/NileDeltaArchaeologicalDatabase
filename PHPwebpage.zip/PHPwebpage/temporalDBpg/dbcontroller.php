<?php

//The code to generate the dropdown cascading menus were taken from
//https://www.youtube.com/watch?v=fE2O6ngJhzA
//Connection corrected for PostgreSQL
//https://www.php.net/manual/es/function.pg-pconnect.php
class DbConnect {
	private $conn_string = "host=POSTGRESQL_DATABASE_URL port=5432 dbname=POSTGRESQL_DATABASE_NAME user=YOUR_USERNAME password=YOUR_PASSWORD"; // change here to match your own values *** THIS IS THE PostgreSQL database
	private $conn;

	function __construct(){
		$this->conn = $this->connectDB();
	}
	function connectDB() {
		$conn = pg_connect($this->conn_string);
		return $conn;
	}
	function runQuery($query){
		$result = pg_query($this->conn,$query);
		while($row=pg_fetch_assoc($result)) {
			$resultset[] = $row;
		}
		if(!empty($resultset))
			return $resultset;
		}
		function numRows($query){
		$result = pg_query($this->conn,$query);
		$rowcount = pg_num_rows($result);
		return $rowcount;
		}
}
?>